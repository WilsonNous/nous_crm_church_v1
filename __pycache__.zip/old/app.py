from flask import Flask
from flask_cors import CORS

# Importando as rotas e os serviços separados
from routes import register_routes

app = Flask(__name__)
CORS(app)

# Registrando as rotas definidas no arquivo routes.py
register_routes(app)

if __name__ == '__main__':
    app.run(debug=True)
