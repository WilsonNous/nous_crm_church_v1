import sqlite3
from contextlib import closing

def get_db_connection():
    """Função para obter a conexão com o banco de dados SQLite"""
    conn = sqlite3.connect('../crm_visitantes.db')
    conn.row_factory = sqlite3.Row
    return conn

def salvar_visitante(nome, telefone, email, data_nascimento, cidade, genero, estado_civil, igreja_atual,
                     frequenta_igreja, indicacao, membro, pedido_oracao, horario_contato):
    """Salva um visitante no banco de dados"""
    try:
        with closing(get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute(''' 
                INSERT INTO visitantes (nome, telefone, email, data_nascimento, cidade, genero, estado_civil, igreja_atual,
                frequenta_igreja, indicacao, membro, pedido_oracao, horario_contato)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (nome, telefone, email, data_nascimento, cidade, genero, estado_civil, igreja_atual,
                  frequenta_igreja, indicacao, membro, pedido_oracao, horario_contato))
            conn.commit()
        return True
    except sqlite3.IntegrityError as e:
        print(f"Erro ao salvar visitante: {e}")
        return False

def buscar_numeros_telefone():
    """Busca os números de telefone dos visitantes no banco de dados"""
    try:
        with closing(get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT telefone FROM visitantes')
            telefones = cursor.fetchall()
            return [row['telefone'] for row in telefones]
    except Exception as e:
        print(f"Erro ao buscar números de telefone: {str(e)}")
        return []

def buscar_status_visitante(visitante_id):
    """Busca o status de um visitante pelo ID"""
    try:
        with closing(get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT fase FROM status WHERE visitante_id = ?', (visitante_id,))
            status = cursor.fetchone()
            return status['fase'] if status else None
    except Exception as e:
        print(f"Erro ao buscar status do visitante: {str(e)}")
        return None
