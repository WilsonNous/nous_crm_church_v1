import os

app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY')
