import os
from twilio.rest import Client
from flask import jsonify
from old.database_v1 import buscar_numeros_telefone
from old.process_message import (normalizar_para_envio,
                                 buscar_status, atualizar_status)
from database import buscar_numeros_telefone
from process_message import (normalizar_telefone,
                             buscar_status, atualizar_status)

# Configurações do Twilio
account_sid = os.getenv('TWILIO_ACCOUNT_SID')
auth_token = os.getenv('TWILIO_AUTH_TOKEN')
twilio_phone_number = '+14155238886'
client = Client(account_sid, auth_token)


def send_whatsapp_messages(messages):
    """Função responsável por enviar mensagens pelo WhatsApp via Twilio"""

    # Buscar todos os números de telefone dos visitantes
    telefones = buscar_numeros_telefone()

    if not telefones:
        return jsonify({"error": "Nenhum número de telefone encontrado no banco de dados"}), 404

    # Normalizar os números de telefone para o formato correto
    telefones_normalizados = [normalizar_telefone(telefone,'envio') for telefone in telefones]

    errors = []

    # Loop pelos números de telefone normalizados
    for telefone in telefones_normalizados:
        try:
            # Buscar o estado atual do visitante (se existe no banco)
            estado_atual = buscar_status(telefone)

            # Se o estado atual for None, isso significa que o visitante não tem status definido
            if estado_atual is None:
                # Atualizamos o status do visitante para "Inicio" após enviar a mensagem do menu
                atualizar_status(telefone, "Inicio")
                estado_atual = "Inicio"

            # Loop pelas mensagens a serem enviadas
            for msg in messages:
                mensagem = msg.get('message')

                # Verificar se a mensagem existe
                if not mensagem:
                    errors.append({"phone": telefone, "error": "Mensagem é obrigatória"})
                    continue

                # Enviar a mensagem via Twilio
                client.messages.create(
                    body=mensagem,
                    from_=f'whatsapp:{twilio_phone_number}',
                    to=f'whatsapp:+55{telefone}'  # Certifique-se de que o número esteja no formato correto
                )

        except Exception as e:
            # Em caso de erro, coletar o número de telefone e o erro para exibir depois
            errors.append({"phone": telefone, "error": str(e)})

    # Verificar se ocorreram erros durante o envio das mensagens
    if errors:
        return jsonify({"status": "partial_success", "errors": errors}), 207

    # Se tudo deu certo, retornamos o sucesso
    return jsonify({"status": "success", "message": "Todas as mensagens foram enviadas com sucesso!"}), 200
