import logging
import sqlite3
from contextlib import closing

from old.database_v1 import get_db_connection  # Importando a função de conexão

# Configurar o logging para registrar os logs em um arquivo
logging.basicConfig(level=logging.INFO, filename='crm_log.log',
                    format='%(asctime)s - %(levelname)s - %(message)s')


def normalizar_telefone(telefone, tipo='banco'):
    """
    Função para normalizar o número de telefone para o formato correto,
    seja para banco de dados ou para envio de mensagens.
    O parâmetro 'tipo' define se é para 'banco' ou 'envio'.
    """
    telefone = ''.join(filter(str.isdigit, telefone.replace('whatsapp:', '').replace('+', '')))

    if telefone.startswith('55'):
        telefone = telefone[2:]

    ddd, numero = telefone[:2], telefone[2:]

    if tipo == 'banco':
        if len(numero) == 8 and not numero.startswith('9'):
            numero = '9' + numero
    elif tipo == 'envio' and len(telefone) == 11 and numero.startswith('9'):
        numero = numero[1:]

    # Retorna o número no formato brasileiro padrão com o DDD
    return f'{ddd}{numero}'


def normalizar_para_envio(telefone: str) -> str:
    """
    Normaliza o número de telefone para envio, removendo o dígito 9, se necessário.

    Parâmetros:
    telefone (str): O número de telefone a ser normalizado.

    Retorna:
    str: O número de telefone normalizado.
    """
    # Remove todos os caracteres não numéricos
    telefone = ''.join(filter(str.isdigit, telefone))

    if len(telefone) < 10:
        raise ValueError(f"Telefone inválido: {telefone}. Número deve ter ao menos 10 dígitos.")

    # Separa o DDD, dígito e número
    ddd: str = telefone[:2]  # Considera os primeiros 2 dígitos como DDD
    digito: str = telefone[2] if len(telefone) > 2 else ''  # O terceiro dígito, se existir
    numero: str = telefone[3:]  # O restante do número

    # Se o número tiver 11 dígitos e começar com '9', remove o dígito '9'
    if len(telefone) == 11 and digito == '9':
        digito = ''  # Remove o dígito '9'

    # Junta novamente as partes, sem o dígito '9', se necessário
    if digito:
        telefone_normalizado: str = f"{ddd}{numero}"
    else:
        telefone_normalizado = f"{ddd}{digito}{numero}"

    return telefone_normalizado


def normalizar_para_recebimento(telefone):
    """
    Função para normalizar o número de telefone para o formato dd9nnnnnnnnn.
    Adiciona o '9' se necessário ao receber o número do Twilio.

    Exemplo:
        Entrada: 'whatsapp:+554898284104'
        Saída: '48998284104' (se necessário)
    """
    # Remove todos os caracteres não numéricos
    telefone = ''.join(filter(str.isdigit, telefone))

    # Remove o código do país '55' para números brasileiros
    if telefone.startswith('55'):
        telefone = telefone[2:]  # Remove os dois primeiros dígitos

    # Separa o DDD e o número
    ddd = telefone[:2]  # Considera os primeiros 2 dígitos como DDD
    numero = telefone[2:]  # O restante do número

    # Verifica se o número tem 8 dígitos e adiciona '9'
    if len(numero) == 8:
        numero = '9' + numero

    # Retorna o número normalizado com DDD
    return f'{ddd}{numero}'


def processar_mensagem(estado_atual, texto_recebido, numero):
    logging.info(f"Função 'processar_mensagem' chamada com estado_atual={estado_atual}, "
                 f"texto_recebido={texto_recebido}, numero={numero}")
    try:
        respostas = {
            "inicio": {
                "1": ("Você deseja se tornar membro. Agradecemos seu interesse!", "batizado"),
                "2": ("Você deseja receber orações. Como podemos ajudá-lo?", "pedido_oracao"),
                "3": ("Quer saber mais sobre os horários dos cultos. Por favor, aguarde.", "fim"),
                "4": ("Você deseja entrar no grupo do WhatsApp da igreja. Enviaremos o link em breve.", "fim"),
                "5": ("Qual outro assunto você gostaria de tratar?", "outro")
            },
            "batizado": {
                "1": ("Ótimo! Fique atento para o próximo passo e nos avise se precisar de mais informações.",
                      "batizado"),
                "2": ("Entendido! Podemos agendar uma conversa para explicar sobre o batismo?",
                      "agendar_batismo")
            }
        }

        if estado_atual in respostas:
            if texto_recebido in respostas[estado_atual]:
                mensagem, novo_status = respostas[estado_atual][texto_recebido]
                enviar_mensagem(numero, mensagem)
                atualizar_status(numero, novo_status)
            else:
                enviar_mensagem(numero, "Desculpe, não entendi sua resposta. Escolha uma opção válida.")
        else:
            enviar_mensagem(numero, "Estado não reconhecido. Reinicie o processo.")
    except Exception as e:
        logging.error(f"Erro na função 'processar_mensagem' para o número {numero}. Detalhes: {e}")


def enviar_mensagem(numero, mensagem):
    logging.info(f"Função 'enviar_mensagem' chamada para o número {numero}")
    try:
        numero = normalizar_telefone(numero, tipo='envio')
        # Função para enviar mensagem, aqui é onde você integraria com o serviço de envio de mensagens (Exemplo: Twilio)
        print(f"Enviando para {numero}: {mensagem}")

        logging.info(f"Mensagem enviada para o número {numero} com sucesso")
    except Exception as e:
        logging.error(f"Erro ao enviar mensagem para o número {numero}. Detalhes: {e}")

def atualizar_status(telefone, novo_status):
    logging.info(f"Função 'atualizar_status' chamada para o telefone {telefone}")
    try:
        with closing(get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE status
                SET fase = ?
                WHERE visitante_id = (SELECT id FROM visitantes WHERE telefone = ?)
            ''', (novo_status, telefone))
            conn.commit()
            if cursor.rowcount > 0:
                logging.info(f"Status atualizado para {novo_status} no telefone {telefone}")
            else:
                logging.warning(f"Nenhum visitante encontrado com o telefone {telefone}")
    except sqlite3.Error as e:
        logging.error(f"Erro ao atualizar o status para o telefone {telefone}. Detalhes: {e}")


def visitante_existe(telefone):
    """Verifica se um visitante com o telefone especificado já existe."""
    try:
        with closing(get_db_connection()) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM visitantes WHERE telefone = ?', (telefone,))
            count = cursor.fetchone()[0]
            return count > 0
    except sqlite3.Error as e:
        print(f"Erro ao verificar visitante: {e}")
        return False


def main():
    logging.info("Função 'main' chamada")
    pass


if __name__ == '__main__':
    main()
