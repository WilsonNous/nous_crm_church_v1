import secrets

# Gera uma chave secreta de 32 bytes e converte para um formato legível (hexadecimal)
secret_key = secrets.token_hex(32)
print(secret_key)
